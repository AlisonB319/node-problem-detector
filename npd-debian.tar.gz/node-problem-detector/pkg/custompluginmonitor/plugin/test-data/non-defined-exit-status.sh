#!/usr/bin/env bash

echo "NON-DEFINED-EXIT-STATUS"
exit 100

