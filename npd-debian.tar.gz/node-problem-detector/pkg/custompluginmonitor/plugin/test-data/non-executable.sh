#!/usr/bin/env bash

echo "NON-EXECUTABLE"
exit -1

