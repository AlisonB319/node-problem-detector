#!/usr/bin/env bash

echo "OK"
exit 0

